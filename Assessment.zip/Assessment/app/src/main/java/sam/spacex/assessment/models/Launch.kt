package sam.spacex.assessment.models

import com.google.gson.annotations.SerializedName

/**
 * This is the basic model of each launch.
 * This includes the relevant information such as mission name,
 * detail URL, launch Year, etc related to each launch.
 *
 */
data class Launch (
  @SerializedName("mission_name"            ) var missionName           : String?               = null,
  @SerializedName("rocket"                  ) var rocket                : Rocket?               = Rocket(),
  @SerializedName("launch_site"             ) var launchSite            : LaunchSite?           = LaunchSite(),
  @SerializedName("launch_year"             ) var launchYear            : String?               = null,
  @SerializedName("links"                   ) var links                 : Links?                = Links(),
  @SerializedName("launch_date_unix"        ) var launchDateUnix        : Int?                  = null
)