package sam.spacex.assessment.models

import com.google.gson.annotations.SerializedName


data class Timeline (

  @SerializedName("webcast_liftoff" ) var webcastLiftoff : Int? = null

)