package sam.spacex.assessment

/**
 * This class is used by the adapter for the
 * list of the launches to update the activity
 * regarding the selected URL of of a launch to
 * view the details related to that launch.
 * This also lets the activity know as to which
 * launch items was selected.
 */
interface LoadFullDetail {
    fun loadDetailsFromAPI(detailAPI: String)

    fun selectedLaunch(number: Int)
}