package sam.spacex.assessment.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import sam.spacex.assessment.LoadFullDetail
import sam.spacex.assessment.R
import sam.spacex.assessment.models.Launch

/**
 * This is the adapter that will display the summary details
 * list items to the user.
 * @param launches The list of the launches including the name, the year,
 * and the URL to each launch.
 * @param loadFullDetail This is the interface that tells the activity
 * which launch was selected. Upon the selection of a launch the activity
 * will then use the URL passed in to display the details related to
 * that selected launch.
 */
class LaunchAdapter(
    private val launches: List<Launch>,
    private val loadFullDetail: LoadFullDetail
) : RecyclerView.Adapter<LaunchAdapter.ViewHolder>() {
    val views = mutableListOf<LaunchAdapter.ViewHolder>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LaunchAdapter.ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.launch_item, parent, false)
        return ViewHolder(view)
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val missionName: TextView
        val rocketName: TextView
        val launchSiteName: TextView
        val dateOfLaunch: TextView
        val launchPatchImage: AppCompatImageView

        init {
            missionName = view.findViewById(R.id.mission_name)
            rocketName = view.findViewById(R.id.rocket_name)
            launchSiteName = view.findViewById(R.id.launch_site_name)
            dateOfLaunch = view.findViewById(R.id.date_of_launch)
            launchPatchImage = view.findViewById(R.id.launch_patch_image)
        }
    }


    override fun onBindViewHolder(holder: LaunchAdapter.ViewHolder, position: Int) {
        holder.missionName.text = "Mission name: ${launches[position].missionName}"
        holder.rocketName.text = "Rocket name: ${launches[position].rocket?.rocketName}"
        holder.launchSiteName.text = "Launch Site name: ${launches[position].launchSite?.siteName}"
        holder.dateOfLaunch.text = "Date of Launch: ${launches[position].launchYear}"

        Glide.with(holder.launchPatchImage.context)
            .load(launches[position].links?.missionPatch)
            .placeholder(R.drawable.place_holder)
            .into(holder.launchPatchImage)

        holder.itemView.setOnClickListener {
            launches[position].links?.articleLink?.let { api ->
                loadFullDetail.loadDetailsFromAPI(
                    api
                )
            }

            views.add(holder)

            if (it.resources.getBoolean(R.bool.isTablet)) {
                it.setBackgroundColor(ContextCompat.getColor(it.context, R.color.yellow))
            }

            for (view in views) {
                if (view != holder) {
                    view.itemView.setBackgroundColor(ContextCompat.getColor(it.context, R.color.white))
                }
            }
            loadFullDetail.selectedLaunch(position)
        }
    }

    override fun getItemCount(): Int {
        return launches.size
    }

}