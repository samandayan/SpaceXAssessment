package sam.spacex.assessment.networking

import retrofit2.Call
import retrofit2.http.GET
import sam.spacex.assessment.models.Launch

/**
 * The Service that uses the base URL to
 * retrieve the launches.
 */
interface LaunchesService {

    /**
     * This is the API call to append
     * launches to the base URL for the
     * purpose of retrieving the launches.
     * The launches will be returned in the form of a list.
     */
    @GET("launches")
    fun getLaunches(): Call<List<Launch>>
}