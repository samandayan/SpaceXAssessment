package sam.spacex.assessment

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import sam.spacex.assessment.adapters.LaunchAdapter
import sam.spacex.assessment.models.Launch

/**
 * This is the Main UI where the list of launches as
 * well as the details pertaining to each launch is
 * displayed. The orientation is handled here based off
 * of the device minimum width. Tablets will use the
 * layout of activity_main_sw600 to display both the
 * list of launches as well as their details.
 */
class MainActivity : AppCompatActivity(), LoadFullDetail {

    lateinit var mViewModel : SpaceXViewModel
    lateinit var mLaunchesList: RecyclerView
    lateinit var mFullDetail: WebView

    var mDetailURL = ""
    var mSelectedChild = -1

    /**
     * This is the life cycle method where the correct
     * layout will be inflated depending on the
     * device size; being a phone or a tablet.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        supportActionBar?.title = getString(R.string.wait_message)

        initialize()
        retrieveLaunches()
        if (savedInstanceState != null && savedInstanceState.getInt("NUMBER") != -1)
            mSelectedChild = savedInstanceState.getInt("NUMBER")
        registerObservers()

        if (savedInstanceState != null && savedInstanceState.getString("URL") != "")
            savedInstanceState.getString("URL")?.let { mFullDetail.loadUrl(it) }
    }

    /**
     * This is used to navigate back to
     * the list of launches after a
     * launch's detail is displayed.
     * This is for the phone variant.
     */
    override fun onBackPressed() {
        if (!(resources.getBoolean(R.bool.isTablet)) && mFullDetail.visibility == View.VISIBLE) {
                mFullDetail.visibility = View.GONE
                mLaunchesList.visibility = View.VISIBLE
        } else {
            super.onBackPressed()
        }
    }

    /**
     * The back button on this activitiy's UI
     * is enabled. After the detail page is
     * displayed on the phone the user may
     * press back on the toolbar to go back
     * to the list of the launches.
     */
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId) {
            android.R.id.home ->  if (!(resources.getBoolean(R.bool.isTablet)) && mFullDetail.visibility == View.VISIBLE) {
                mFullDetail.visibility = View.GONE
                mLaunchesList.visibility = View.VISIBLE
            }
        }
        return true
    }

    /**
     * The URL and selected launch are saved
     * here so that during an orientation change
     * the same detail is loaded and the user
     * is scrolled back to the same postion of
     * the selected launch.
     */
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("URL", mDetailURL)
        outState.putInt("NUMBER", mSelectedChild)
    }

    /**
     * The references to the UI views are
     * set here. This is set so that the
     * views may be updated programmatically.
     */
    private fun initialize() {
        mViewModel = ViewModelProvider(MainActivity@this).get(SpaceXViewModel::class.java)
        mLaunchesList = findViewById(R.id.launches_list)
        mFullDetail = findViewById(R.id.full_details)
    }

    /**
     * This method will trigger call in the
     * viewModel to retrieve the launches
     * using the repository in the view model.
     */
    private fun retrieveLaunches() {
        mViewModel.lookUp()
    }

    /**
     * The list of launches id delivered by
     * the view model MutableLiveData.
     * This registration is used by the activity
     * to update the adapter in order to display
     * the list of the launches.
     */
    private fun registerObservers() {
        mViewModel.launches.observe(this
        ) {
            supportActionBar?.title = getString(R.string.select_item)
            val launchComparator = Comparator { launch1: Launch, launch2: Launch -> launch1.launchDateUnix ?: 0 - (launch2.launchDateUnix ?: 0) }
            val launchAdapter = LaunchAdapter(it.sortedWith(launchComparator), this)
            mLaunchesList.layoutManager = LinearLayoutManager(MainActivity@this)
            mLaunchesList.adapter = launchAdapter
            if (mSelectedChild != -1)
                mLaunchesList.scrollToPosition(mSelectedChild)
        }
    }

    /**
     * This is the implementing method which will be called
     * from inside of the Launches Adapter upon selecting
     * a specific launch. The activity is notified of a
     * selection and the selected launch's URL to update
     * the details page with.
     * @param detailAPI The URL to load into the details page.
     */
    override fun loadDetailsFromAPI(detailAPI: String) {
        if (!(resources.getBoolean(R.bool.isTablet))) {
            mLaunchesList.visibility = View.GONE
            mFullDetail.visibility = View.VISIBLE
        }
        mFullDetail.loadUrl(detailAPI)
        mDetailURL = detailAPI
    }

    /**
     * This is used by the adapter to notify the
     * activity of the index of the selected launch.
     * This number is then used after selection to
     * scroll to the selected child once the screen
     * is rotated.
     * @param The child to scroll to.
     */
    override fun selectedLaunch(number: Int) {
        mSelectedChild = number
    }
}