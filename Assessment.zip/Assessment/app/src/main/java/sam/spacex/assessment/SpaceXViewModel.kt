package sam.spacex.assessment

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import sam.spacex.assessment.models.Launch
import sam.spacex.assessment.networking.SpaceXRepository

/**
 * This ViewModel works with the repository
 * to retrieve the list of the launches.
 * The delivery of the launches list to the
 * activity is done here as well. When a UI
 * component registers an observer on the
 * launches MultableLiveData then once the list
 * is retrieved the activity will get notified
 * and will be notified about the retrieved
 * launches and its contents.
 */
class SpaceXViewModel: ViewModel() {
    val repository = SpaceXRepository()

    var launches = MutableLiveData<List<Launch>>()

    fun lookUp() {
        viewModelScope.launch {
            repository.getLaunches().enqueue(object :Callback<List<Launch>>{
                override fun onResponse(call: Call<List<Launch>>, response: Response<List<Launch>>) {
                    launches.postValue(response.body())
                }
                override fun onFailure(call: Call<List<Launch>>, t: Throwable) {
                }
            })
        }
    }
}