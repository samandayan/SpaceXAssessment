package sam.spacex.assessment.networking

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create
import java.security.KeyStore
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.*

/**
 * This repository builds the base retrofit
 * to download the list of launches.
 * This will be used in conjunction with LaunchesService
 * to retrieve the list of Launches from the server in the
 * form of a list.
 */
class SpaceXRepository {

    private val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl("https://api.spacexdata.com/v3/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    val service = retrofit.create<LaunchesService>()

   suspend fun getLaunches() = service.getLaunches()
}